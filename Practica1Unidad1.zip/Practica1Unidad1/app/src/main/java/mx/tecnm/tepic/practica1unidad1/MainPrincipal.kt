package mx.tecnm.tepic.practica1unidad1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main_principal.*

class MainPrincipal : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_principal)

        button1.setOnClickListener {
            var otraVentana = Intent(this, MainActivity::class.java)
            startActivity(otraVentana)
        }

        button2.setOnClickListener {
            var otraVentana = Intent(this, MainActivity2::class.java)
            startActivity(otraVentana)
        }

        button3.setOnClickListener {
            var otraVentana = Intent(this, MainActivity3::class.java)
            startActivity(otraVentana)
        }

        button4.setOnClickListener {
            var otraVentana = Intent(this, MainActivity4::class.java)
            startActivity(otraVentana)
        }

    }
}